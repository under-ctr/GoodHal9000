#pragma once

#include "yasm_imports.h"

//******************************************************************************
// Function:     HalInitialize
// Description:  Initializes the HAL library. Must be called before any other
//               HAL function.
// Returns:      void
// Parameter:    void
//******************************************************************************
void
HalInitialize(
    void
    );