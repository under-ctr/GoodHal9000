#pragma once

#define PCI_NO_OF_BUSES                                 256
#define PCI_NO_OF_DEVICES                               32
#define PCI_NO_OF_FUNCTIONS                             8