#pragma once

WORD
EthEepromReadWord(
    IN      PETH_INTERNAL_REGS      EthRegs,
    IN      WORD                    Address
    );