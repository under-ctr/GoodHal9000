#pragma once

void
DumpLapic(
    IN      PVOID       LapicBaseAddress
    );