#pragma once

#include "../../Ata/headers/ata_commands.h"


void
DumpAtaIdentifyCommand(
    IN      PATA_IDENTIFY_RESPONSE          Identify
    );