#pragma once

#include "multiboot.h"

void
DumpParameters(
    IN ASM_PARAMETERS* Parameters
    );