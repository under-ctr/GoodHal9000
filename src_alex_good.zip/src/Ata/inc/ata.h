#pragma once

FUNC_DriverEntry                                AtaDriverEntry;